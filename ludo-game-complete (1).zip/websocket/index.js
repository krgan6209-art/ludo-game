const { rollDice, canMovePiece, movePiece, nextTurn } = require('../game/logic');
const { findGameById, updateGame, addChatMessage, updateUser } = require('../database');
const { verifyToken } = require('../utils/security');
const { checkRateLimit } = require('../utils/helpers');

const rooms = new Map();
const connections = new Map();

function setupWebSocket(server) {
  const WebSocket = require('ws');
  const wss = new WebSocket.Server({ server });

  wss.on('connection', (ws) => {
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message);
        await handleMessage(ws, data);
      } catch (err) {
        ws.send(JSON.stringify({ type: 'error', message: err.message }));
      }
    });

    ws.on('close', () => handleDisconnect(ws));
  });

  setInterval(() => {
    wss.clients.forEach((ws) => {
      if (!ws.isAlive) return ws.terminate();
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);

  return wss;
}

async function handleMessage(ws, data) {
  switch (data.type) {
    case 'auth': await handleAuth(ws, data); break;
    case 'join_room': await handleJoinRoom(ws, data); break;
    case 'roll_dice': await handleRollDice(ws, data); break;
    case 'move_piece': await handleMovePiece(ws, data); break;
    case 'chat_message': await handleChatMessage(ws, data); break;
    case 'reaction': await handleReaction(ws, data); break;
    case 'voice_signal': await handleVoiceSignal(ws, data); break;
    case 'leave_game': await handleLeaveGame(ws, data); break;
    default: ws.send(JSON.stringify({ type: 'error', message: 'نوع پیام نامعتبر' }));
  }
}

async function handleAuth(ws, data) {
  try {
    const decoded = verifyToken(data.token);
    ws.userId = decoded.id;
    ws.username = decoded.username;
    connections.set(ws.userId, ws);
    ws.send(JSON.stringify({ type: 'auth_success', user: { id: decoded.id, username: decoded.username } }));
  } catch (err) {
    ws.send(JSON.stringify({ type: 'auth_error', message: err.message }));
  }
}

async function handleJoinRoom(ws, data) {
  const { roomCode } = data;
  const game = require('../database').findGameByRoomCode(roomCode);
  if (!game) return ws.send(JSON.stringify({ type: 'error', message: 'اتاق یافت نشد' }));
  ws.roomCode = roomCode; ws.gameId = game.id;
  if (!rooms.has(roomCode)) rooms.set(roomCode, new Set());
  rooms.get(roomCode).add(ws);
  ws.send(JSON.stringify({ type: 'joined_room', game }));
  broadcast(roomCode, { type: 'player_joined', userId: ws.userId, username: ws.username }, ws);
}

async function handleRollDice(ws, data) {
  const game = findGameById(ws.gameId);
  if (!game) return ws.send(JSON.stringify({ type: 'error', message: 'بازی یافت نشد' }));
  const playerIndex = game.state.players[1].id === ws.userId ? 1 : 2;
  if (game.state.currentTurn !== playerIndex) return ws.send(JSON.stringify({ type: 'error', message: 'نوبت شما نیست' }));
  const dice = rollDice();
  game.state.dice = dice;
  game.state.rollCount += 1;
  updateGame(game.id, { state: game.state });
  broadcast(ws.roomCode, { type: 'dice_rolled', playerIndex, dice, gameState: game.state });
}

async function handleMovePiece(ws, data) {
  const { pieceIndex } = data;
  const game = findGameById(ws.gameId);
  if (!game) return ws.send(JSON.stringify({ type: 'error', message: 'بازی یافت نشد' }));
  const playerIndex = game.state.players[1].id === ws.userId ? 1 : 2;
  if (game.state.currentTurn !== playerIndex) return ws.send(JSON.stringify({ type: 'error', message: 'نوبت شما نیست' }));
  const dice = game.state.dice;
  if (!dice) return ws.send(JSON.stringify({ type: 'error', message: 'ابتدا تاس بیندازید' }));
  if (!canMovePiece(game.state, playerIndex, pieceIndex, dice)) return ws.send(JSON.stringify({ type: 'error', message: 'این حرکت مجاز نیست' }));
  const result = movePiece(game.state, playerIndex, pieceIndex, dice);
  if (!result.success) return ws.send(JSON.stringify({ type: 'error', message: result.error }));
  const samePlayer = dice === 6;
  nextTurn(game.state, samePlayer);
  updateGame(game.id, { state: game.state });
  broadcast(ws.roomCode, { type: 'piece_moved', playerIndex, pieceIndex, newPos: result.newPos, hit: result.hit, gameState: game.state });
  if (game.state.status === 'finished') {
    broadcast(ws.roomCode, { type: 'game_finished', winner: game.state.winner, gameState: game.state });
    const winnerId = game.state.players[game.state.winner].id;
    const loserId = game.state.players[game.state.winner === 1 ? 2 : 1].id;
    const wUser = updateUser(winnerId, {});
    const lUser = updateUser(loserId, {});
    updateUser(winnerId, { wins: (wUser?.wins || 0) + 1, gamesPlayed: (wUser?.gamesPlayed || 0) + 1 });
    updateUser(loserId, { losses: (lUser?.losses || 0) + 1, gamesPlayed: (lUser?.gamesPlayed || 0) + 1 });
  }
}

async function handleChatMessage(ws, data) {
  const { message } = data;
  if (!message || !message.trim()) return;
  if (message.length > 500) return ws.send(JSON.stringify({ type: 'error', message: 'پیام خیلی طولانی است' }));
  const limit = checkRateLimit(`chat_${ws.userId}`, 5, 60000);
  if (!limit.allowed) return ws.send(JSON.stringify({ type: 'error', message: `لطفاً ${limit.retryAfter} ثانیه دیگر تلاش کنید` }));
  const chatMsg = { id: Date.now().toString(), gameId: ws.gameId, senderId: ws.userId, senderName: ws.username, message: message.trim(), createdAt: new Date().toISOString() };
  addChatMessage(chatMsg);
  broadcast(ws.roomCode, { type: 'chat_message', message: chatMsg });
}

async function handleReaction(ws, data) {
  const { emoji } = data;
  broadcast(ws.roomCode, { type: 'reaction', senderId: ws.userId, senderName: ws.username, emoji });
}

async function handleVoiceSignal(ws, data) {
  broadcast(ws.roomCode, { ...data, senderId: ws.userId }, ws);
}

async function handleLeaveGame(ws, data) {
  if (ws.roomCode) {
    broadcast(ws.roomCode, { type: 'player_left', userId: ws.userId, username: ws.username });
    const room = rooms.get(ws.roomCode);
    if (room) room.delete(ws);
  }
}

function handleDisconnect(ws) {
  if (ws.userId) connections.delete(ws.userId);
  if (ws.roomCode) {
    const room = rooms.get(ws.roomCode);
    if (room) room.delete(ws);
    broadcast(ws.roomCode, { type: 'player_disconnected', userId: ws.userId, username: ws.username });
  }
}

function broadcast(roomCode, data, excludeWs = null) {
  const room = rooms.get(roomCode);
  if (!room) return;
  room.forEach((client) => {
    if (client !== excludeWs && client.readyState === 1) client.send(JSON.stringify(data));
  });
}

module.exports = { setupWebSocket };
