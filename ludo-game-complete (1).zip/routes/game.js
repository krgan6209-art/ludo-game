const { createGame, findGameByRoomCode, updateGame, findGameById } = require('../database');
const { generateRoomCode, generateId } = require('../utils/helpers');
const { createInitialState } = require('../game/logic');

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); } catch (e) { resolve({}); }
    });
  });
}

module.exports = async function gameRoutes(req, res) {
  const url = req.url;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  if (url === '/api/game/create' && req.method === 'POST') {
    const roomCode = generateRoomCode();
    const game = createGame({
      id: generateId(),
      roomCode,
      player1: req.user.id,
      player2: null,
      state: createInitialState(req.user.id, null),
      currentTurn: 1,
      status: 'waiting',
      winner: null,
      createdAt: new Date().toISOString(),
      finishedAt: null,
    });
    return res.end(JSON.stringify({ game }));
  }

  if (url === '/api/game/join' && req.method === 'POST') {
    const body = await parseBody(req);
    const { roomCode } = body || {};
    if (!roomCode) {
      res.statusCode = 400;
      return res.end(JSON.stringify({ error: 'کد اتاق الزامی است' }));
    }
    const game = findGameByRoomCode(roomCode.toUpperCase());
    if (!game) {
      res.statusCode = 404;
      return res.end(JSON.stringify({ error: 'اتاق یافت نشد' }));
    }
    if (game.player2 && game.player2 !== req.user.id) {
      res.statusCode = 403;
      return res.end(JSON.stringify({ error: 'این اتاق پر است' }));
    }
    if (game.player1 === req.user.id) {
      return res.end(JSON.stringify({ game }));
    }
    game.player2 = req.user.id;
    game.state.players[2].id = req.user.id;
    game.status = 'playing';
    updateGame(game.id, { player2: req.user.id, state: game.state, status: 'playing' });
    return res.end(JSON.stringify({ game }));
  }

  if (url.startsWith('/api/game/') && req.method === 'GET') {
    const id = url.split('/')[3];
    const game = findGameById(id);
    if (!game) {
      res.statusCode = 404;
      return res.end(JSON.stringify({ error: 'بازی یافت نشد' }));
    }
    return res.end(JSON.stringify({ game }));
  }

  res.statusCode = 404;
  res.end(JSON.stringify({ error: 'مسیر یافت نشد' }));
};
