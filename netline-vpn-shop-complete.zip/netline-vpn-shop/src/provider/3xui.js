const axios=require('axios');
class ThreeXUIProvider{constructor({baseUrl,apiToken,inboundId}){this.inboundId=Number(inboundId);this.http=axios.create({baseURL:baseUrl.replace(/\/$/,''),timeout:15000,headers:{Authorization:`Bearer ${apiToken}`}})}
async createClient({email,totalGB,expiryTime,tgId}){const r=await this.http.post('/panel/api/clients/add',{client:{email,totalGB:Math.floor(totalGB*1024*1024*1024),expiryTime,tgId:String(tgId),enable:true,limitIp:0,limitHwid:0},inboundIds:[this.inboundId]});if(r.data?.success===false)throw Error(r.data.msg||'provider error');return r.data}
async links(email){const r=await this.http.get(`/panel/api/clients/links/${encodeURIComponent(email)}`);if(r.data?.success===false)throw Error(r.data.msg||'provider error');return r.data.obj||r.data}}
module.exports=ThreeXUIProvider;
