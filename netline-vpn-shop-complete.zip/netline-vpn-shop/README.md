# NetLine VPN Shop

ربات تلگرام + پنل RTL فارسی + PostgreSQL + کیف پول + پرداخت کارت‌به‌کارت + تیکت + محصولات/سفارش‌ها + Docker + Migration + اتصال 3x-ui.

## اجرا
cp .env.example .env
مقادیر `.env` را تنظیم کنید و سپس:

```bash
docker compose up -d --build
docker compose exec bot npx sequelize-cli db:migrate
docker compose exec bot npx sequelize-cli db:seed:all
```

پنل: `http://SERVER:8080`

**امنیت:** هر توکن رباتی که قبلاً در چت یا جای عمومی افشا شده را با BotFather تعویض کنید. `.env` را منتشر نکنید. پنل را در محیط واقعی پشت HTTPS قرار دهید.

Provider در `src/provider/3xui.js` از Bearer API Token و endpointهای ساخت client و دریافت لینک اشتراک 3x-ui استفاده می‌کند. Inbound ID و آدرس API باید متعلق به پنل خودتان باشد.
